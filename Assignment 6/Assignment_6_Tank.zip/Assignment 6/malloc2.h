int *malloc2(int size);
int free2(void *ptr);
int *realloc2(void *ptr, int size);
int memcheck2(void *ptr, int size);